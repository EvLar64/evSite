var networks = {"breakfast_desc.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "breakfast_desc.tsv",
    "name" : "breakfast_desc.tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "791",
        "shared_name" : "(CONT'D)",
        "name" : "(CONT'D)",
        "SUID" : 791,
        "sceneNum" : 41.0,
        "selected" : false
      },
      "position" : {
        "x" : -674.9548708386974,
        "y" : -433.8818330582658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "shared_name" : "(to Carl)",
        "name" : "(to Carl)",
        "SUID" : 785,
        "sceneNum" : 38.0,
        "selected" : false
      },
      "position" : {
        "x" : -199.18830814612068,
        "y" : 655.5236019697481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "shared_name" : "(laughing)",
        "name" : "(laughing)",
        "SUID" : 779,
        "sceneNum" : 37.0,
        "selected" : false
      },
      "position" : {
        "x" : 559.9348129882153,
        "y" : -82.99907079057743
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "shared_name" : "(smiling)",
        "name" : "(smiling)",
        "SUID" : 773,
        "sceneNum" : 35.0,
        "selected" : false
      },
      "position" : {
        "x" : -421.5651870117847,
        "y" : 544.2042253521126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "shared_name" : "(with pride)",
        "name" : "(with pride)",
        "SUID" : 764,
        "sceneNum" : 33.0,
        "selected" : false
      },
      "position" : {
        "x" : -449.7873004816745,
        "y" : -254.3166876592336
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "shared_name" : "(with pity)",
        "name" : "(with pity)",
        "SUID" : 758,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 36.02506166998194,
        "y" : -569.1720545447341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "shared_name" : "(crying again)",
        "name" : "(crying again)",
        "SUID" : 752,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 36.02506166998205,
        "y" : -784.4194947510407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "shared_name" : "(furious and sobbing)",
        "name" : "(furious and sobbing)",
        "SUID" : 743,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 408.8445643064483,
        "y" : -784.4194947510408
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "shared_name" : "(furious once again)",
        "name" : "(furious once again)",
        "SUID" : 737,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : -50.79066046892967,
        "y" : 697.6462276582138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "shared_name" : "(furious and screaming at Claire)",
        "name" : "(furious and screaming at Claire)",
        "SUID" : 731,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : -38.69010840531769,
        "y" : 836.6886188413014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "shared_name" : "(quietly)",
        "name" : "(quietly)",
        "SUID" : 719,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 114.81109288506218,
        "y" : -863.2055259661207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "shared_name" : "(furious)",
        "name" : "(furious)",
        "SUID" : 713,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 307.4348129882153,
        "y" : -94.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "shared_name" : "(he turns to Claire)",
        "name" : "(he turns to Claire)",
        "SUID" : 707,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 201.57914673088908,
        "y" : 807.5146493753282
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "shared_name" : "(he's crying)",
        "name" : "(he's crying)",
        "SUID" : 698,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 707.6381091309054,
        "y" : 64.70422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "shared_name" : "(with feeling)",
        "name" : "(with feeling)",
        "SUID" : 674,
        "sceneNum" : 28.0,
        "selected" : false
      },
      "position" : {
        "x" : -592.5651870117847,
        "y" : 478.20422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "shared_name" : "(like it's obvious)",
        "name" : "(like it's obvious)",
        "SUID" : 668,
        "sceneNum" : 28.0,
        "selected" : false
      },
      "position" : {
        "x" : -574.7458747336595,
        "y" : -225.79570851712083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "shared_name" : "(shrugs)",
        "name" : "(shrugs)",
        "SUID" : 662,
        "sceneNum" : 28.0,
        "selected" : false
      },
      "position" : {
        "x" : 7.187372781908834,
        "y" : -676.7957746478875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "shared_name" : "(flustered)",
        "name" : "(flustered)",
        "SUID" : 647,
        "sceneNum" : 24.0,
        "selected" : false
      },
      "position" : {
        "x" : 437.68225319452176,
        "y" : -676.7957746478874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "shared_name" : "(screaming)",
        "name" : "(screaming)",
        "SUID" : 641,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : -145.5651870117847,
        "y" : -176.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "shared_name" : "(to everybody)",
        "name" : "(to everybody)",
        "SUID" : 629,
        "sceneNum" : 21.0,
        "selected" : false
      },
      "position" : {
        "x" : -136.96630058812366,
        "y" : 57.704225352112644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "shared_name" : "(to Vernon)",
        "name" : "(to Vernon)",
        "SUID" : 617,
        "sceneNum" : 21.0,
        "selected" : false
      },
      "position" : {
        "x" : 201.5791467308884,
        "y" : 378.89380132889687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "shared_name" : "(as his father--yelling)",
        "name" : "(as his father--yelling)",
        "SUID" : 590,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : -38.69010840531814,
        "y" : 349.7198318629239
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "(as himself--yelling)",
        "name" : "(as himself--yelling)",
        "SUID" : 584,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : 284.22992809607933,
        "y" : 472.18724776414183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "shared_name" : "(as himself)",
        "name" : "(as himself)",
        "SUID" : 569,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : -94.05195430551885,
        "y" : 593.2042253521126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "shared_name" : "(as his mother)",
        "name" : "(as his mother)",
        "SUID" : 560,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : -199.1883081461208,
        "y" : 530.884848734478
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "shared_name" : "(as his father)",
        "name" : "(as his father)",
        "SUID" : 554,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : 53.65134183717123,
        "y" : 740.907521494803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "(quiet and motherly)",
        "name" : "(quiet and motherly)",
        "SUID" : 548,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : 284.2299280960798,
        "y" : 714.221202940083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "shared_name" : "(kiddie)",
        "name" : "(kiddie)",
        "SUID" : 527,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : -141.26579138304578,
        "y" : 420.5227136524047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "shared_name" : "(loud)",
        "name" : "(loud)",
        "SUID" : 521,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : -50.79066046892979,
        "y" : 488.76222304601174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "shared_name" : "(in a kiddie voice)",
        "name" : "(in a kiddie voice)",
        "SUID" : 515,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : 85.03988798785235,
        "y" : 851.7121603874434
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "shared_name" : "(in a loud and friendly voice)",
        "name" : "(in a loud and friendly voice)",
        "SUID" : 509,
        "sceneNum" : 18.0,
        "selected" : false
      },
      "position" : {
        "x" : 201.3546379798613,
        "y" : 593.2042253521126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "shared_name" : "(to Allison)",
        "name" : "(to Allison)",
        "SUID" : 491,
        "sceneNum" : 33.0,
        "selected" : false
      },
      "position" : {
        "x" : -140.5651870117847,
        "y" : -271.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "(resentfully)",
        "name" : "(resentfully)",
        "SUID" : 476,
        "sceneNum" : 14.0,
        "selected" : false
      },
      "position" : {
        "x" : 114.81109288506218,
        "y" : -490.386023329654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "shared_name" : "allison",
        "name" : "allison",
        "SUID" : 462,
        "selected" : false
      },
      "position" : {
        "x" : -451.5651870117847,
        "y" : 458.20422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "shared_name" : "(pronouncing it correctly)",
        "name" : "(pronouncing it correctly)",
        "SUID" : 456,
        "sceneNum" : 14.0,
        "selected" : false
      },
      "position" : {
        "x" : 330.0585330913684,
        "y" : -863.2055259661208
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "shared_name" : "(Bender mouths \"I'm cracking skulls\")",
        "name" : "(Bender mouths \"I'm cracking skulls\")",
        "SUID" : 447,
        "sceneNum" : 12.0,
        "selected" : false
      },
      "position" : {
        "x" : -239.026768097527,
        "y" : -82.76995692266564
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "shared_name" : "(to everyone)",
        "name" : "(to everyone)",
        "SUID" : 441,
        "sceneNum" : 21.0,
        "selected" : false
      },
      "position" : {
        "x" : -404.16407343544574,
        "y" : -29.113593835548272
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "shared_name" : "(worried)",
        "name" : "(worried)",
        "SUID" : 426,
        "sceneNum" : 12.0,
        "selected" : false
      },
      "position" : {
        "x" : 222.4348129882153,
        "y" : -892.0432148541938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "shared_name" : "(loudly)",
        "name" : "(loudly)",
        "SUID" : 420,
        "sceneNum" : 14.0,
        "selected" : false
      },
      "position" : {
        "x" : -532.5651870117847,
        "y" : 635.2042253521126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "shared_name" : "(under his breath)",
        "name" : "(under his breath)",
        "SUID" : 414,
        "sceneNum" : 12.0,
        "selected" : false
      },
      "position" : {
        "x" : 53.65134183717123,
        "y" : 445.50092920942257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "shared_name" : "(pointing)",
        "name" : "(pointing)",
        "SUID" : 396,
        "sceneNum" : 12.0,
        "selected" : false
      },
      "position" : {
        "x" : -404.16407343544574,
        "y" : 144.52204453977356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "shared_name" : "(in a stern voice)",
        "name" : "(in a stern voice)",
        "SUID" : 381,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : 158.09334414327225,
        "y" : 697.6462276582138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "(defensive)",
        "name" : "(defensive)",
        "SUID" : 375,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : 559.9348129882153,
        "y" : 212.40752149480272
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "shared_name" : "(with mock hurt)",
        "name" : "(with mock hurt)",
        "SUID" : 366,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : 85.03988798785167,
        "y" : 334.69629031678187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "shared_name" : "(laughs)",
        "name" : "(laughs)",
        "SUID" : 354,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : 330.05853309136864,
        "y" : -490.3860233296541
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "(to Brian)",
        "name" : "(to Brian)",
        "SUID" : 342,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 95.4348129882153,
        "y" : -18.795774647887356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "shared_name" : "(to no one imparticular)",
        "name" : "(to no one imparticular)",
        "SUID" : 333,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : -449.7873004816745,
        "y" : -485.2748616365411
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "shared_name" : "(with mock enthusiasm)",
        "name" : "(with mock enthusiasm)",
        "SUID" : 327,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : 314.0579341225514,
        "y" : 593.2042253521126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "shared_name" : "(to himself)",
        "name" : "(to himself)",
        "SUID" : 312,
        "sceneNum" : 27.0,
        "selected" : false
      },
      "position" : {
        "x" : 149.4348129882153,
        "y" : 244.20422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "shared_name" : "(yells)",
        "name" : "(yells)",
        "SUID" : 306,
        "sceneNum" : 7.0,
        "selected" : false
      },
      "position" : {
        "x" : -239.02676809752694,
        "y" : 198.17840762689093
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "shared_name" : "vernon",
        "name" : "vernon",
        "SUID" : 304,
        "selected" : false
      },
      "position" : {
        "x" : -284.6695967308138,
        "y" : 57.704225352112644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "shared_name" : "(screams)",
        "name" : "(screams)",
        "SUID" : 295,
        "sceneNum" : 12.0,
        "selected" : false
      },
      "position" : {
        "x" : 188.4348129882153,
        "y" : -83.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "shared_name" : "(another beat)",
        "name" : "(another beat)",
        "SUID" : 286,
        "sceneNum" : 14.0,
        "selected" : false
      },
      "position" : {
        "x" : 158.09334414327225,
        "y" : 488.76222304601174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "shared_name" : "(a beat)",
        "name" : "(a beat)",
        "SUID" : 280,
        "sceneNum" : 28.0,
        "selected" : false
      },
      "position" : {
        "x" : -536.5651870117847,
        "y" : 370.20422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "shared_name" : "(to Andrew and Claire)",
        "name" : "(to Andrew and Claire)",
        "SUID" : 274,
        "sceneNum" : 6.0,
        "selected" : false
      },
      "position" : {
        "x" : -141.26579138304555,
        "y" : 765.8857370518213
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "shared_name" : "(to Claire)",
        "name" : "(to Claire)",
        "SUID" : 268,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : -436.5651870117847,
        "y" : 292.20422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "shared_name" : "bender",
        "name" : "bender",
        "SUID" : 266,
        "selected" : false
      },
      "position" : {
        "x" : 53.65134183717123,
        "y" : 593.2042253521126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "(to Andrew)",
        "name" : "(to Andrew)",
        "SUID" : 260,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : -6.565187011784701,
        "y" : -84.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "shared_name" : "(nervous)",
        "name" : "(nervous)",
        "SUID" : 251,
        "sceneNum" : 6.0,
        "selected" : false
      },
      "position" : {
        "x" : -674.9548708386974,
        "y" : -305.7097162375089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "shared_name" : "(to Claire about Bender)",
        "name" : "(to Claire about Bender)",
        "SUID" : 245,
        "sceneNum" : 6.0,
        "selected" : false
      },
      "position" : {
        "x" : 412.2315168455252,
        "y" : 64.70422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "shared_name" : "andrew",
        "name" : "andrew",
        "SUID" : 243,
        "selected" : false
      },
      "position" : {
        "x" : 559.9348129882153,
        "y" : 64.70422535211264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "shared_name" : "(to Bender)",
        "name" : "(to Bender)",
        "SUID" : 237,
        "sceneNum" : 21.0,
        "selected" : false
      },
      "position" : {
        "x" : 7.434812988215299,
        "y" : -152.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "shared_name" : "(disgusted)",
        "name" : "(disgusted)",
        "SUID" : 228,
        "sceneNum" : 6.0,
        "selected" : false
      },
      "position" : {
        "x" : 408.8445643064488,
        "y" : -569.1720545447341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "shared_name" : "(to herself)",
        "name" : "(to herself)",
        "SUID" : 222,
        "sceneNum" : 6.0,
        "selected" : false
      },
      "position" : {
        "x" : 222.4348129882153,
        "y" : -461.5483344415809
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "shared_name" : "claire",
        "name" : "claire",
        "SUID" : 220,
        "selected" : false
      },
      "position" : {
        "x" : 222.4348129882153,
        "y" : -676.7957746478874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "(quietly to himself)",
        "name" : "(quietly to himself)",
        "SUID" : 214,
        "sceneNum" : 6.0,
        "selected" : false
      },
      "position" : {
        "x" : -574.7458747336597,
        "y" : -513.7958407786538
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "(angry)",
        "name" : "(angry)",
        "SUID" : 208,
        "sceneNum" : 30.0,
        "selected" : false
      },
      "position" : {
        "x" : 487.4348129882153,
        "y" : -1220.7957746478874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "(annoyingly)",
        "name" : "(annoyingly)",
        "SUID" : 202,
        "sceneNum" : 3.0,
        "selected" : false
      },
      "position" : {
        "x" : 623.4348129882153,
        "y" : -1485.7957746478874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "misc",
        "name" : "misc",
        "SUID" : 200,
        "selected" : false
      },
      "position" : {
        "x" : 576.4348129882153,
        "y" : -1395.7957746478874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "(upset)",
        "name" : "(upset)",
        "SUID" : 185,
        "sceneNum" : 3.0,
        "selected" : false
      },
      "position" : {
        "x" : -394.175503184872,
        "y" : -369.79577464788736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "brian",
        "name" : "brian",
        "SUID" : 183,
        "selected" : false
      },
      "position" : {
        "x" : -541.8787993275621,
        "y" : -369.79577464788736
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "776",
        "source" : "462",
        "target" : "773",
        "shared_name" : "allison (interacts with) (smiling)",
        "shared_interaction" : "interacts with",
        "name" : "allison (interacts with) (smiling)",
        "interaction" : "interacts with",
        "SUID" : 776,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "source" : "462",
        "target" : "268",
        "shared_name" : "allison (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "allison (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 680,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "462",
        "target" : "674",
        "shared_name" : "allison (interacts with) (with feeling)",
        "shared_interaction" : "interacts with",
        "name" : "allison (interacts with) (with feeling)",
        "interaction" : "interacts with",
        "SUID" : 677,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "462",
        "target" : "280",
        "shared_name" : "allison (interacts with) (a beat)",
        "shared_interaction" : "interacts with",
        "name" : "allison (interacts with) (a beat)",
        "interaction" : "interacts with",
        "SUID" : 659,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "462",
        "target" : "420",
        "shared_name" : "allison (interacts with) (loudly)",
        "shared_interaction" : "interacts with",
        "name" : "allison (interacts with) (loudly)",
        "interaction" : "interacts with",
        "SUID" : 464,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "source" : "304",
        "target" : "312",
        "shared_name" : "vernon (interacts with) (to himself)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to himself)",
        "interaction" : "interacts with",
        "SUID" : 656,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "304",
        "target" : "268",
        "shared_name" : "vernon (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 653,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "304",
        "target" : "237",
        "shared_name" : "vernon (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 635,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "source" : "304",
        "target" : "629",
        "shared_name" : "vernon (interacts with) (to everybody)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to everybody)",
        "interaction" : "interacts with",
        "SUID" : 632,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "304",
        "target" : "260",
        "shared_name" : "vernon (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 626,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "304",
        "target" : "280",
        "shared_name" : "vernon (interacts with) (a beat)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (a beat)",
        "interaction" : "interacts with",
        "SUID" : 623,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "304",
        "target" : "441",
        "shared_name" : "vernon (interacts with) (to everyone)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to everyone)",
        "interaction" : "interacts with",
        "SUID" : 614,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "source" : "304",
        "target" : "491",
        "shared_name" : "vernon (interacts with) (to Allison)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Allison)",
        "interaction" : "interacts with",
        "SUID" : 494,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "source" : "304",
        "target" : "447",
        "shared_name" : "vernon (interacts with) (Bender mouths \"I'm cracking skulls\")",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (Bender mouths \"I'm cracking skulls\")",
        "interaction" : "interacts with",
        "SUID" : 450,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "source" : "304",
        "target" : "441",
        "shared_name" : "vernon (interacts with) (to everyone)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to everyone)",
        "interaction" : "interacts with",
        "SUID" : 444,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "source" : "304",
        "target" : "237",
        "shared_name" : "vernon (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 438,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "source" : "304",
        "target" : "342",
        "shared_name" : "vernon (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 435,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "source" : "304",
        "target" : "237",
        "shared_name" : "vernon (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 432,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "source" : "304",
        "target" : "237",
        "shared_name" : "vernon (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 411,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "source" : "304",
        "target" : "260",
        "shared_name" : "vernon (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 408,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "source" : "304",
        "target" : "260",
        "shared_name" : "vernon (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 405,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "source" : "304",
        "target" : "396",
        "shared_name" : "vernon (interacts with) (pointing)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (pointing)",
        "interaction" : "interacts with",
        "SUID" : 399,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "source" : "304",
        "target" : "268",
        "shared_name" : "vernon (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 393,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "304",
        "target" : "237",
        "shared_name" : "vernon (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 390,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "304",
        "target" : "312",
        "shared_name" : "vernon (interacts with) (to himself)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (to himself)",
        "interaction" : "interacts with",
        "SUID" : 315,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "source" : "304",
        "target" : "306",
        "shared_name" : "vernon (interacts with) (yells)",
        "shared_interaction" : "interacts with",
        "name" : "vernon (interacts with) (yells)",
        "interaction" : "interacts with",
        "SUID" : 309,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "source" : "266",
        "target" : "785",
        "shared_name" : "bender (interacts with) (to Carl)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Carl)",
        "interaction" : "interacts with",
        "SUID" : 788,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "source" : "266",
        "target" : "737",
        "shared_name" : "bender (interacts with) (furious once again)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (furious once again)",
        "interaction" : "interacts with",
        "SUID" : 740,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "266",
        "target" : "731",
        "shared_name" : "bender (interacts with) (furious and screaming at Claire)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (furious and screaming at Claire)",
        "interaction" : "interacts with",
        "SUID" : 734,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "source" : "266",
        "target" : "713",
        "shared_name" : "bender (interacts with) (furious)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (furious)",
        "interaction" : "interacts with",
        "SUID" : 716,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "source" : "266",
        "target" : "707",
        "shared_name" : "bender (interacts with) (he turns to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (he turns to Claire)",
        "interaction" : "interacts with",
        "SUID" : 710,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "266",
        "target" : "260",
        "shared_name" : "bender (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 683,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "source" : "266",
        "target" : "641",
        "shared_name" : "bender (interacts with) (screaming)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (screaming)",
        "interaction" : "interacts with",
        "SUID" : 644,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "source" : "266",
        "target" : "312",
        "shared_name" : "bender (interacts with) (to himself)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to himself)",
        "interaction" : "interacts with",
        "SUID" : 638,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "266",
        "target" : "617",
        "shared_name" : "bender (interacts with) (to Vernon)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Vernon)",
        "interaction" : "interacts with",
        "SUID" : 620,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "source" : "266",
        "target" : "342",
        "shared_name" : "bender (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 596,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "source" : "266",
        "target" : "590",
        "shared_name" : "bender (interacts with) (as his father--yelling)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as his father--yelling)",
        "interaction" : "interacts with",
        "SUID" : 593,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "source" : "266",
        "target" : "584",
        "shared_name" : "bender (interacts with) (as himself--yelling)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as himself--yelling)",
        "interaction" : "interacts with",
        "SUID" : 587,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "source" : "266",
        "target" : "554",
        "shared_name" : "bender (interacts with) (as his father)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as his father)",
        "interaction" : "interacts with",
        "SUID" : 581,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "266",
        "target" : "569",
        "shared_name" : "bender (interacts with) (as himself)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as himself)",
        "interaction" : "interacts with",
        "SUID" : 578,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "source" : "266",
        "target" : "554",
        "shared_name" : "bender (interacts with) (as his father)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as his father)",
        "interaction" : "interacts with",
        "SUID" : 575,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "source" : "266",
        "target" : "569",
        "shared_name" : "bender (interacts with) (as himself)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as himself)",
        "interaction" : "interacts with",
        "SUID" : 572,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "266",
        "target" : "554",
        "shared_name" : "bender (interacts with) (as his father)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as his father)",
        "interaction" : "interacts with",
        "SUID" : 566,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "266",
        "target" : "560",
        "shared_name" : "bender (interacts with) (as his mother)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as his mother)",
        "interaction" : "interacts with",
        "SUID" : 563,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "266",
        "target" : "554",
        "shared_name" : "bender (interacts with) (as his father)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (as his father)",
        "interaction" : "interacts with",
        "SUID" : 557,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "source" : "266",
        "target" : "548",
        "shared_name" : "bender (interacts with) (quiet and motherly)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (quiet and motherly)",
        "interaction" : "interacts with",
        "SUID" : 551,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "266",
        "target" : "521",
        "shared_name" : "bender (interacts with) (loud)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (loud)",
        "interaction" : "interacts with",
        "SUID" : 545,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "source" : "266",
        "target" : "527",
        "shared_name" : "bender (interacts with) (kiddie)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (kiddie)",
        "interaction" : "interacts with",
        "SUID" : 542,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "source" : "266",
        "target" : "521",
        "shared_name" : "bender (interacts with) (loud)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (loud)",
        "interaction" : "interacts with",
        "SUID" : 539,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "source" : "266",
        "target" : "527",
        "shared_name" : "bender (interacts with) (kiddie)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (kiddie)",
        "interaction" : "interacts with",
        "SUID" : 536,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "source" : "266",
        "target" : "521",
        "shared_name" : "bender (interacts with) (loud)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (loud)",
        "interaction" : "interacts with",
        "SUID" : 533,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "source" : "266",
        "target" : "527",
        "shared_name" : "bender (interacts with) (kiddie)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (kiddie)",
        "interaction" : "interacts with",
        "SUID" : 530,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "source" : "266",
        "target" : "521",
        "shared_name" : "bender (interacts with) (loud)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (loud)",
        "interaction" : "interacts with",
        "SUID" : 524,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "source" : "266",
        "target" : "515",
        "shared_name" : "bender (interacts with) (in a kiddie voice)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (in a kiddie voice)",
        "interaction" : "interacts with",
        "SUID" : 518,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "source" : "266",
        "target" : "509",
        "shared_name" : "bender (interacts with) (in a loud and friendly voice)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (in a loud and friendly voice)",
        "interaction" : "interacts with",
        "SUID" : 512,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "source" : "266",
        "target" : "342",
        "shared_name" : "bender (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 497,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "source" : "266",
        "target" : "280",
        "shared_name" : "bender (interacts with) (a beat)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (a beat)",
        "interaction" : "interacts with",
        "SUID" : 488,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "266",
        "target" : "286",
        "shared_name" : "bender (interacts with) (another beat)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (another beat)",
        "interaction" : "interacts with",
        "SUID" : 485,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "source" : "266",
        "target" : "280",
        "shared_name" : "bender (interacts with) (a beat)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (a beat)",
        "interaction" : "interacts with",
        "SUID" : 482,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "source" : "266",
        "target" : "342",
        "shared_name" : "bender (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 470,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "source" : "266",
        "target" : "295",
        "shared_name" : "bender (interacts with) (screams)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (screams)",
        "interaction" : "interacts with",
        "SUID" : 453,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "source" : "266",
        "target" : "420",
        "shared_name" : "bender (interacts with) (loudly)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (loudly)",
        "interaction" : "interacts with",
        "SUID" : 423,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "source" : "266",
        "target" : "414",
        "shared_name" : "bender (interacts with) (under his breath)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (under his breath)",
        "interaction" : "interacts with",
        "SUID" : 417,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "source" : "266",
        "target" : "342",
        "shared_name" : "bender (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 402,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "source" : "266",
        "target" : "295",
        "shared_name" : "bender (interacts with) (screams)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (screams)",
        "interaction" : "interacts with",
        "SUID" : 387,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "source" : "266",
        "target" : "381",
        "shared_name" : "bender (interacts with) (in a stern voice)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (in a stern voice)",
        "interaction" : "interacts with",
        "SUID" : 384,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "266",
        "target" : "366",
        "shared_name" : "bender (interacts with) (with mock hurt)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (with mock hurt)",
        "interaction" : "interacts with",
        "SUID" : 369,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "266",
        "target" : "260",
        "shared_name" : "bender (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 363,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "source" : "266",
        "target" : "342",
        "shared_name" : "bender (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 348,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "source" : "266",
        "target" : "342",
        "shared_name" : "bender (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 345,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "266",
        "target" : "268",
        "shared_name" : "bender (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 339,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "266",
        "target" : "327",
        "shared_name" : "bender (interacts with) (with mock enthusiasm)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (with mock enthusiasm)",
        "interaction" : "interacts with",
        "SUID" : 330,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "266",
        "target" : "312",
        "shared_name" : "bender (interacts with) (to himself)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to himself)",
        "interaction" : "interacts with",
        "SUID" : 324,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "266",
        "target" : "268",
        "shared_name" : "bender (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 321,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "266",
        "target" : "286",
        "shared_name" : "bender (interacts with) (another beat)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (another beat)",
        "interaction" : "interacts with",
        "SUID" : 292,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "source" : "266",
        "target" : "286",
        "shared_name" : "bender (interacts with) (another beat)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (another beat)",
        "interaction" : "interacts with",
        "SUID" : 289,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "266",
        "target" : "280",
        "shared_name" : "bender (interacts with) (a beat)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (a beat)",
        "interaction" : "interacts with",
        "SUID" : 283,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "source" : "266",
        "target" : "274",
        "shared_name" : "bender (interacts with) (to Andrew and Claire)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Andrew and Claire)",
        "interaction" : "interacts with",
        "SUID" : 277,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "source" : "266",
        "target" : "268",
        "shared_name" : "bender (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "bender (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 271,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "source" : "243",
        "target" : "779",
        "shared_name" : "andrew (interacts with) (laughing)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (laughing)",
        "interaction" : "interacts with",
        "SUID" : 782,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "243",
        "target" : "698",
        "shared_name" : "andrew (interacts with) (he's crying)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (he's crying)",
        "interaction" : "interacts with",
        "SUID" : 701,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "243",
        "target" : "342",
        "shared_name" : "andrew (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 695,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "source" : "243",
        "target" : "342",
        "shared_name" : "andrew (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 467,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "source" : "243",
        "target" : "375",
        "shared_name" : "andrew (interacts with) (defensive)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (defensive)",
        "interaction" : "interacts with",
        "SUID" : 378,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "243",
        "target" : "342",
        "shared_name" : "andrew (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 372,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "243",
        "target" : "312",
        "shared_name" : "andrew (interacts with) (to himself)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (to himself)",
        "interaction" : "interacts with",
        "SUID" : 318,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "source" : "243",
        "target" : "295",
        "shared_name" : "andrew (interacts with) (screams)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (screams)",
        "interaction" : "interacts with",
        "SUID" : 301,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "243",
        "target" : "237",
        "shared_name" : "andrew (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 257,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "243",
        "target" : "245",
        "shared_name" : "andrew (interacts with) (to Claire about Bender)",
        "shared_interaction" : "interacts with",
        "name" : "andrew (interacts with) (to Claire about Bender)",
        "interaction" : "interacts with",
        "SUID" : 248,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "source" : "220",
        "target" : "491",
        "shared_name" : "claire (interacts with) (to Allison)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Allison)",
        "interaction" : "interacts with",
        "SUID" : 770,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "220",
        "target" : "758",
        "shared_name" : "claire (interacts with) (with pity)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (with pity)",
        "interaction" : "interacts with",
        "SUID" : 761,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "220",
        "target" : "752",
        "shared_name" : "claire (interacts with) (crying again)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (crying again)",
        "interaction" : "interacts with",
        "SUID" : 755,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "source" : "220",
        "target" : "743",
        "shared_name" : "claire (interacts with) (furious and sobbing)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (furious and sobbing)",
        "interaction" : "interacts with",
        "SUID" : 746,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "220",
        "target" : "713",
        "shared_name" : "claire (interacts with) (furious)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (furious)",
        "interaction" : "interacts with",
        "SUID" : 728,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "220",
        "target" : "208",
        "shared_name" : "claire (interacts with) (angry)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (angry)",
        "interaction" : "interacts with",
        "SUID" : 725,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "source" : "220",
        "target" : "719",
        "shared_name" : "claire (interacts with) (quietly)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (quietly)",
        "interaction" : "interacts with",
        "SUID" : 722,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "source" : "220",
        "target" : "260",
        "shared_name" : "claire (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 704,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "220",
        "target" : "260",
        "shared_name" : "claire (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 689,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "source" : "220",
        "target" : "641",
        "shared_name" : "claire (interacts with) (screaming)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (screaming)",
        "interaction" : "interacts with",
        "SUID" : 686,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "220",
        "target" : "662",
        "shared_name" : "claire (interacts with) (shrugs)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (shrugs)",
        "interaction" : "interacts with",
        "SUID" : 665,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "source" : "220",
        "target" : "647",
        "shared_name" : "claire (interacts with) (flustered)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (flustered)",
        "interaction" : "interacts with",
        "SUID" : 650,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "source" : "220",
        "target" : "260",
        "shared_name" : "claire (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 611,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "source" : "220",
        "target" : "237",
        "shared_name" : "claire (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 602,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "source" : "220",
        "target" : "260",
        "shared_name" : "claire (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 599,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "source" : "220",
        "target" : "342",
        "shared_name" : "claire (interacts with) (to Brian)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Brian)",
        "interaction" : "interacts with",
        "SUID" : 506,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "source" : "220",
        "target" : "476",
        "shared_name" : "claire (interacts with) (resentfully)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (resentfully)",
        "interaction" : "interacts with",
        "SUID" : 479,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "source" : "220",
        "target" : "237",
        "shared_name" : "claire (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 473,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "source" : "220",
        "target" : "456",
        "shared_name" : "claire (interacts with) (pronouncing it correctly)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (pronouncing it correctly)",
        "interaction" : "interacts with",
        "SUID" : 459,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "source" : "220",
        "target" : "426",
        "shared_name" : "claire (interacts with) (worried)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (worried)",
        "interaction" : "interacts with",
        "SUID" : 429,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "220",
        "target" : "237",
        "shared_name" : "claire (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 360,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "source" : "220",
        "target" : "354",
        "shared_name" : "claire (interacts with) (laughs)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (laughs)",
        "interaction" : "interacts with",
        "SUID" : 357,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "220",
        "target" : "237",
        "shared_name" : "claire (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 351,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "220",
        "target" : "295",
        "shared_name" : "claire (interacts with) (screams)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (screams)",
        "interaction" : "interacts with",
        "SUID" : 298,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "220",
        "target" : "260",
        "shared_name" : "claire (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 263,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "220",
        "target" : "237",
        "shared_name" : "claire (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 240,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "220",
        "target" : "228",
        "shared_name" : "claire (interacts with) (disgusted)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (disgusted)",
        "interaction" : "interacts with",
        "SUID" : 234,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "source" : "220",
        "target" : "228",
        "shared_name" : "claire (interacts with) (disgusted)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (disgusted)",
        "interaction" : "interacts with",
        "SUID" : 231,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "source" : "220",
        "target" : "222",
        "shared_name" : "claire (interacts with) (to herself)",
        "shared_interaction" : "interacts with",
        "name" : "claire (interacts with) (to herself)",
        "interaction" : "interacts with",
        "SUID" : 225,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "200",
        "target" : "208",
        "shared_name" : "misc (interacts with) (angry)",
        "shared_interaction" : "interacts with",
        "name" : "misc (interacts with) (angry)",
        "interaction" : "interacts with",
        "SUID" : 211,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "200",
        "target" : "202",
        "shared_name" : "misc (interacts with) (annoyingly)",
        "shared_interaction" : "interacts with",
        "name" : "misc (interacts with) (annoyingly)",
        "interaction" : "interacts with",
        "SUID" : 205,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "source" : "183",
        "target" : "791",
        "shared_name" : "brian (interacts with) (CONT'D)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (CONT'D)",
        "interaction" : "interacts with",
        "SUID" : 794,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "183",
        "target" : "764",
        "shared_name" : "brian (interacts with) (with pride)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (with pride)",
        "interaction" : "interacts with",
        "SUID" : 767,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "183",
        "target" : "491",
        "shared_name" : "brian (interacts with) (to Allison)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to Allison)",
        "interaction" : "interacts with",
        "SUID" : 749,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "183",
        "target" : "260",
        "shared_name" : "brian (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 692,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "183",
        "target" : "668",
        "shared_name" : "brian (interacts with) (like it's obvious)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (like it's obvious)",
        "interaction" : "interacts with",
        "SUID" : 671,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "source" : "183",
        "target" : "268",
        "shared_name" : "brian (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 608,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "183",
        "target" : "260",
        "shared_name" : "brian (interacts with) (to Andrew)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to Andrew)",
        "interaction" : "interacts with",
        "SUID" : 605,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "source" : "183",
        "target" : "237",
        "shared_name" : "brian (interacts with) (to Bender)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to Bender)",
        "interaction" : "interacts with",
        "SUID" : 503,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "source" : "183",
        "target" : "268",
        "shared_name" : "brian (interacts with) (to Claire)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to Claire)",
        "interaction" : "interacts with",
        "SUID" : 500,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "183",
        "target" : "333",
        "shared_name" : "brian (interacts with) (to no one imparticular)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (to no one imparticular)",
        "interaction" : "interacts with",
        "SUID" : 336,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "183",
        "target" : "251",
        "shared_name" : "brian (interacts with) (nervous)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (nervous)",
        "interaction" : "interacts with",
        "SUID" : 254,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "source" : "183",
        "target" : "214",
        "shared_name" : "brian (interacts with) (quietly to himself)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (quietly to himself)",
        "interaction" : "interacts with",
        "SUID" : 217,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "source" : "183",
        "target" : "185",
        "shared_name" : "brian (interacts with) (upset)",
        "shared_interaction" : "interacts with",
        "name" : "brian (interacts with) (upset)",
        "interaction" : "interacts with",
        "SUID" : 193,
        "sceneMarker" : "scene",
        "BEND_MAP_ID" : 193,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}